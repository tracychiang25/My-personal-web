import React, {useState} from 'react';

function FavoriteColour(){
    const [colour, setColour] = useState("");

    return(
    <div className="colour">
    <p>My favorite colour is {colour}</p>
    <button type="button"
    onClick={()=> setColour("blue")}>Blue</button>
    <button type="button"
    onClick={()=> setColour("red")}>Red</button>
    <br></br>
    <button type="button"
    onClick={()=> setColour("yellow")}>Yellow</button>
    </div>
    );
    
}
export default FavoriteColour;
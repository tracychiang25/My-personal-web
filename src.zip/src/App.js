import Navbar from './Navbar';
import Home from './Home';
import FavoriteColour from './FavoriteColour';
import HeroImage from './HeroImage';

function App() {
  return (
    <div className="App">
      <Navbar />
      <HeroImage/> 
   {/*<div className="content">
        <FavoriteColour />
      </div> */}   
      
      
    </div>
  );
}

export default App;

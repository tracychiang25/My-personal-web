
function Home(){
    return(
        <div calssName="home">
            <h2>Home</h2>
        </div>
    )
}
export default Home;